from django.apps import AppConfig


class cuentasConfig(AppConfig):
    name = 'cuentas'
